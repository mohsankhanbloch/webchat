﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using WebChatApp.Common;
using WebChatApp.Data;
using WebChatApp.Models;
using WebChatApp.ViewModels;

namespace WebChatApp.Controllers
{
    public class AccountController : Controller
    {
        public IConfiguration _configuration { get; }
        private readonly WebChatDbContext _context;
        public AccountController(WebChatDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public IActionResult Login()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(UserModel model)
        {
            if (string.IsNullOrEmpty(model.UserName) || string.IsNullOrEmpty(model.Password))
            {
                ViewBag.Message = "Please enter userName and password...!";
                return View();
            }


            model.Password = CommonFunctions.getHashSha256(model.Password);
            var users = _context.Users.FirstOrDefault(a => a.UserName.ToLower() == model.UserName.ToLower());
            if (users == null)
            {
                ViewBag.Message = "Invalid UserName";
                return View();
            }
            else
            {
                if (users.Password != model.Password)
                {
                    ViewBag.Message = "Invalid Password";
                    return View();
                }
                var token = Authenticate(users);
                int expiryInMinutes = _configuration.GetValue<int>("SessionExpiryInMinutes");
                CookieOptions options = new CookieOptions();
                options.Expires = DateTime.Now.AddMinutes(expiryInMinutes);
                Response.Cookies.Append("token", token, options);
                return RedirectToAction("Index", "Home");
            }
        }

        private string Authenticate(Users model)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration.GetValue<string>("TokenSecret"));
            int expiryInMinutes = _configuration.GetValue<int>("SessionExpiryInMinutes");
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, model.UserName),
                    new Claim("Id", model.Id.ToString())
                }),

                Expires = DateTime.Now.AddMinutes(expiryInMinutes),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            string tokenCreated = tokenHandler.WriteToken(token);

            return tokenCreated;
        }

        public IActionResult Register()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Register(UserModel model)
        {
            if (string.IsNullOrEmpty(model.UserName) || string.IsNullOrEmpty(model.Password))
            {
                ViewBag.Message = "Please enter userName and password...!";
                return View();
            }

            model.Password = CommonFunctions.getHashSha256(model.Password);
            var user = _context.Users.FirstOrDefault(a => a.UserName.ToLower() == model.UserName.ToLower());
            if (user == null)
            {
                Users newUser = new Users();
                newUser.UserName = model.UserName;
                newUser.Password = model.Password;
                _context.Users.Add(newUser);
                _context.SaveChanges();

                var token = Authenticate(newUser);
                int expiryInMinutes = _configuration.GetValue<int>("SessionExpiryInMinutes");
                CookieOptions options = new CookieOptions();
                options.Expires = DateTime.Now.AddMinutes(expiryInMinutes);
                Response.Cookies.Append("token", token, options);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Message = "UserName already exist...!";
                return View();
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Logout()
        {
            foreach (var cookie in Request.Cookies.Keys)
            {
                Response.Cookies.Delete(cookie);
            }            
            return RedirectToAction("Login", "Account");
        }
    }
}