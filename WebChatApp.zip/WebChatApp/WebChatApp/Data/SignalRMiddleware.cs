﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebChatApp.Data
{
    public class SignalRMiddleware
    {
        private readonly RequestDelegate _next;

        public SignalRMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var request = httpContext.Request;

            var cookies = httpContext.Request.Cookies;

            foreach (var cookie in cookies)
            {
                if (request.Path.StartsWithSegments("/webchat", StringComparison.OrdinalIgnoreCase) && cookie.Key == "token")
                {
                    request.Headers.Add("Authorization", $"Bearer {cookie.Value}");
                }
            }
            await _next(httpContext);
        }
    }
}
