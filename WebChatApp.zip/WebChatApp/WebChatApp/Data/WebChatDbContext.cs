﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebChatApp.Models;

namespace WebChatApp.Data
{
    public class WebChatDbContext : DbContext
    {
        public WebChatDbContext(DbContextOptions<WebChatDbContext> options)
          : base(options)
        { }

        public DbSet<Users> Users { get; set; }
        public DbSet<Messages> Messages{ get; set; }
    }
}
