﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebChatApp.ViewModels
{
    public class UserIdViewModel
    {
        public int RecieverId { get; set; }
    }
}
