﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebChatApp.ViewModels
{
    public class UserViewModel
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public bool IsOnline { get; set; }
        public string ConnectionId { get; set; }
        public int UnReadMessageCount { get; set; }
        public DateTime LastLoginTime { get; set; }
    }
}
