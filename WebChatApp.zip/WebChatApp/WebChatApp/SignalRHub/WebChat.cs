﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebChatApp.Common;
using WebChatApp.Data;
using WebChatApp.Models;
using WebChatApp.ViewModels;

namespace WebChatApp.SignalRHub
{
    //[Authorize(JwtBearerDefaults.AuthenticationScheme)]
    [Authorize]
    public class WebChat : Hub
    {
        private readonly WebChatDbContext _context;
        public WebChat(WebChatDbContext context)
        {
            _context = context;
        }

        public override async Task OnConnectedAsync()
        {
            var userName = Context.User.Identity.Name;
            var userId = Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault();

            var user = _context.Users.Where(x => x.Id == Convert.ToInt32(userId)).FirstOrDefault();
            if (user != null)
            {
                user.IsOnline = true;
                user.ConnectionId = Context.ConnectionId;
                _context.Users.Update(user);
                _context.SaveChanges();
            }


            await Clients.Client(Context.ConnectionId).SendAsync("UserProfile", new BaseResponse { Success = true, Data = user });

            await updateOnConnect();

            await GetMessageCount();

            //var users = _context.Users.Where(x => x.Id != Convert.ToInt32(userId)).Select(x => new UserViewModel
            //{
            //    ConnectionId = x.ConnectionId,
            //    Id = x.Id,
            //    IsOnline = x.IsOnline,
            //    LastLoginTime = x.LastLoginTime,
            //    UserName = x.UserName,
            //    UnReadMessageCount = _context.Messages.Where(t => t.SenderId == x.Id && t.RecieverId == Convert.ToInt32(userId) && t.IsRead == false).Count()

            //}).OrderByDescending(x => x.LastLoginTime).ToList();

            //await Clients.Clients(Context.ConnectionId).SendAsync("GetAllUserList", new BaseResponse { Success = true, Data = users });

            await Clients.Others.SendAsync("updateUser", new BaseResponse { Success = true, Data = user });
        }

        public override async Task OnDisconnectedAsync(Exception ex)
        {
            var user = _context.Users.Where(x => x.ConnectionId == Context.ConnectionId).FirstOrDefault();
            if (user != null)
            {
                user.IsOnline = false;
                user.ConnectionId = null;
                user.LastLoginTime = DateTime.Now;
                _context.Users.Update(user);
                _context.SaveChanges();
            }

            //var users = _context.Users.Select(x => new UserViewModel
            //{
            //    ConnectionId = x.ConnectionId,
            //    Id = x.Id,
            //    IsOnline = x.IsOnline,
            //    LastLoginTime = x.LastLoginTime,
            //    UserName = x.UserName
            //}).OrderByDescending(x => x.LastLoginTime).ToList();

            //await Clients.All.SendAsync("GetAllUserList", new BaseResponse { Success = true, Data = users });
            await Clients.Others.SendAsync("updateUser", new BaseResponse { Success = true, Data = user });
            //await Clients.All.SendAsync("clientDisconnect");
        }

        public async Task GetAllUser()
        {
            var loginUserId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());
            var users = _context.Users.Where(x => x.Id != loginUserId).Select(x => new UserViewModel
            {
                ConnectionId = x.ConnectionId,
                Id = x.Id,
                IsOnline = x.IsOnline,
                LastLoginTime = x.LastLoginTime,
                UserName = x.UserName
            }).OrderByDescending(x => x.LastLoginTime).ToList();
            await Clients.Client(Context.ConnectionId).SendAsync("GetAllUserList", new BaseResponse { Success = true, Data = users });
        }

        public async Task GetChatHistory(UserIdViewModel model)
        {
            var loginUserId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());
            var chathistory = _context.Messages.Where(x => (x.SenderId == loginUserId && x.RecieverId == model.RecieverId) || (x.SenderId == model.RecieverId && x.RecieverId == loginUserId)).ToList();
            await Clients.Client(Context.ConnectionId).SendAsync("GetChatHistory", new BaseResponse { Success = true, Data = chathistory });
        }

        public async Task SendMessage(MessageViewModel model)
        {
            Messages message = new Messages();
            message.CreatedTime = DateTime.Now;
            message.Message = model.Message;
            message.RecieverId = model.RecieverId;
            message.SenderId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());
            message.IsSent = true;
            message.IsDeliverd = false;
            message.IsRead = false;
            _context.Messages.Add(message);
            _context.SaveChanges();

            await Clients.Client(Context.ConnectionId).SendAsync("SenderChatHistory", new BaseResponse { Success = true, Data = message });

            var reciverUser = _context.Users.Where(x => x.Id == model.RecieverId).FirstOrDefault();
            if (reciverUser.ConnectionId != null)
            {
                await Clients.Client(reciverUser.ConnectionId).SendAsync("RecieverChatHistory", new BaseResponse { Success = true, Data = message });
            }
        }

        public async Task deliveredMessage(MessageViewModel model)
        {
            var message = _context.Messages.Where(x => x.Id == model.Id).FirstOrDefault();
            if (message != null)
            {
                message.IsDeliverd = true;
                _context.Messages.Update(message);
                _context.SaveChanges();
            }

            var user = _context.Users.Where(x => x.Id == message.SenderId).FirstOrDefault();
            if (user != null)
                await Clients.Client(user.ConnectionId).SendAsync("UpdateDeliverdMessage", new BaseResponse { Success = true, Data = message });

        }

        public async Task updateUnReadMessages(UserIdViewModel model)
        {
            var loginUserId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());
            var messages = _context.Messages.Where(u => u.SenderId == model.RecieverId && u.RecieverId == loginUserId && u.IsRead == false).ToList();

            foreach (var item in messages)
            {
                item.IsRead = true;
                item.IsDeliverd = true;
            }
            if (messages.Count > 0)
            {
                _context.Messages.UpdateRange(messages);
                _context.SaveChanges();

                var user = _context.Users.Where(x => x.Id == messages[0].SenderId).FirstOrDefault();
                if (user != null)
                {
                    if(user.ConnectionId!=null)
                    await Clients.Client(user.ConnectionId).SendAsync("updateUnReadMessage", new BaseResponse { Success = true, Data = messages });
                }
                   
            }

            await GetMessageCount();
        }

        public async Task updateOnConnect()
        {
            var userId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());

            var messages = _context.Messages.Where(u => u.RecieverId == userId && u.IsSent == true && u.IsDeliverd == false && u.IsRead == false).ToList();

            if (messages.Count > 0)
            {
                foreach (var item in messages)
                {
                    item.IsDeliverd = true;
                }
                _context.Messages.UpdateRange(messages);
                _context.SaveChanges();
            }
            await Clients.Others.SendAsync("UpdateOnConnect", new BaseResponse { Success = true, Data = messages });
        }

        public async Task GetMessageCount()
        {
            var userId = Convert.ToInt32(Context.User.Claims.Where(x => x.Type == "Id").Select(x => x.Value).FirstOrDefault());
            var users = _context.Users.Where(x => x.Id != Convert.ToInt32(userId)).Select(x => new UserViewModel
            {
                ConnectionId = x.ConnectionId,
                Id = x.Id,
                IsOnline = x.IsOnline,
                LastLoginTime = x.LastLoginTime,
                UserName = x.UserName,
                UnReadMessageCount = 0 //_context.Messages.Where(t => t.SenderId == x.Id && t.RecieverId == userId && t.IsRead == false).Count()

            }).OrderByDescending(x => x.LastLoginTime).ToList();

            foreach (var item in users)
            {
                item.UnReadMessageCount = _context.Messages.Where(t => t.SenderId == item.Id && t.RecieverId == userId && t.IsRead == false).Count();
            }


            await Clients.Client(Context.ConnectionId).SendAsync("GetAllUserList", new BaseResponse { Success = true, Data = users });
        }

    }
}
